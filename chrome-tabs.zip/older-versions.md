### Older versions

This project attempts to keep up to date with the latest design of Google Chrome. Here is a list of prior visual styles:

#### Chrome 53–69 rounded-style "Material Design" ([4ee0906b93](https://github.com/adamschwartz/chrome-tabs/tree/4ee0906b93c139e699fd289b4ef9f0dd16addf09))

<img width=868 src=https://github.com/adamschwartz/chrome-tabs/raw/4ee0906b93c139e699fd289b4ef9f0dd16addf09/chrome-tabs.gif>

<br><br><br><br><br>

#### Pre-Chrome 52 “Material Design” ([0c8c8f1880](https://github.com/adamschwartz/chrome-tabs/tree/0c8c8f18802cf67091151bb812d9693bee55b085))

![](https://github.com/adamschwartz/chrome-tabs/raw/0c8c8f18802cf67091151bb812d9693bee55b085/chrome-tabs.gif)

#### Pre rMBP ([c1b0b0eb8c](https://github.com/adamschwartz/chrome-tabs/tree/c1b0b0eb8c9d2452ee23520802abd7edf71200a8))

![](https://github.com/adamschwartz/chrome-tabs/raw/c1b0b0eb8c9d2452ee23520802abd7edf71200a8/chrome-tabs.gif)
