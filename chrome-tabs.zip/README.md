### Chrome Tabs in Chrome

Exactly what you think this is. Go wild.

Drag-and-drop support provided by [Draggabilly](https://github.com/desandro/draggabilly) by @desandro.

### [Live demo](http://adamschwartz.co/chrome-tabs/)

<img width=714 src=http://adamschwartz.co/chrome-tabs/chrome-tabs.gif>

<br>

[Older versions](older-versions.md)
